Vtiger.Class('Settings_ChangeWorker_Js', {


  UpdateActions : function (){

    jQuery( ".update" ).click( function() {
         var Fromid= $('#fromid').val();
         var Toid= $('#toid').val();
         var Mname= $('#mname').val();
          var params = {};
          params['module'] = 'Vtiger';
          params['parent'] = 'Settings';
          params['action'] = 'ChangeWorkerUpdate';
          params['fromid'] = Fromid; 
          params['toid'] = Toid; 
          params['mname'] = Mname;
  
          app.request.post({"data":params}).then(
            function(err,data) {
                  if(err === null){
                      
                      var successfullSaveMessage = app.vtranslate('UPDATE SUEESSFULLY');
                      app.helper.showSuccessNotification({'message':successfullSaveMessage});
                                        
                  }else {
                      app.helper.showErrorNotification({'message' : err.message});
                  }
            });      
      });

  },
 
  registerEvents : function() {
  
    this.UpdateActions();
    
    
  }
 
});

jQuery(document).ready( function() {
    var Changeuser = new Settings_ChangeWorker_Js();
    Changeuser.registerEvents();
} );
