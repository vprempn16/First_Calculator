<?php
 class Settings_Vtiger_ChangeWorkerUpdate_Action extends Settings_Vtiger_Basic_Action {

	public function process(Vtiger_Request $request) {
     global $adb;
       
    //$adb->setDebug(true);
     $response = new Vtiger_Response();
        try{

          $sql="UPDATE vtiger_crmentity SET smownerid=? WHERE setype=? AND smownerid= ?; ";

            $adb->pquery( $sql ,array($request->get('toid'),$request->get('mname'),$request->get('fromid'))); 

            $response->setResult(array('success'=>'true'));

        }catch(Exception $e){
           $response->setError($e->getCode(), $e->getMessage());
        }
        $response->emit();
   
              }

              
              }
               // UPDATE  vtiger_crmentity SET smownerid = 5 WHERE vtiger_crmentity.crmid = 6;
             // UPDATE vtiger_crmentity SET smownerid=5 WHERE setype='WarehouseTransfer' AND smownerid= 1
?>

