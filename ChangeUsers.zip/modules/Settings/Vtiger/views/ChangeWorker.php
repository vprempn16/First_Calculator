<?php

class Settings_Vtiger_ChangeWorker_View extends Settings_Vtiger_Index_View {

    public function process(Vtiger_Request $request){

        global $adb;
        $viewer = $this->getViewer($request);


        $qualifiedModuleName = $request->getModule(false);

        $modules = $this->getModule();
        $module=$this->getUser(); 

        

        
        $viewer->assign('return', $module);
        $viewer->assign('Edit', $modules);
        $viewer->view('ChangeWorkerEdit.tpl', $qualifiedModuleName);  


    }
        function getUser(){
            global $adb;
            $result=$adb->pquery( "SELECT id,user_name FROM vtiger_users ;",array());

            // echo "<pre>";
            // print_r($value);
            // echo "</pre>";
            $num_row = $adb->num_rows($result); 
            $returns = Array();
            if($num_row> 0){
                for ($i=0;$i<$num_row;$i++){
                     $returns[$i]['id'] = $adb->query_result($result,$i,'id');
                    $returns[$i]['user_name'] = $adb->query_result($result,$i,'user_name');
                }
            }
            return $returns;
        }


     function getModule(){
        global $adb;
            $result=$adb->pquery( "SELECT  tabid,name FROM vtiger_tab ;",array());
            $num_rows = $adb->num_rows($result);
            $return  = Array();
            if($num_rows > 0){
                for ($i=0;$i<$num_rows;$i++){
                     $return[$i]['tabid'] = $adb->query_result($result,$i,'tabid');
                    $return[$i]['name'] = $adb->query_result($result,$i,'name');

                }
            }
            return $return;
        }

        
      function getContactsDetails($contactid){
        global $adb;
            $result=$adb->pquery( "SELECT firstname, lastname FROM vtiger_contactdetails WHERE contactid=?  ;",array($contactid));
            $num_rows = $adb->num_rows($result);
            $return  = Array();
            if($num_rows > 0){
                for ($i=0;$i<$num_rows;$i++){

                    $return[$i]['firstname'] = $adb->query_result($result,$i,'firstname');
                    $return[$i]['lastname'] = $adb->query_result($result,$i,'lastname');

                }
            }
            return $return;
        }

       function getHeaderScripts(Vtiger_Request $request) {
        $headerScriptInstances = parent::getHeaderScripts($request);
        $moduleName = $request->getModule();

        $jsFileNames = array(
            "modules.Settings.$moduleName.resources.ChangeWorker"
        );

        $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
        return $headerScriptInstances;
    }
}
