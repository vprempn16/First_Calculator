<!-- 

include_once 'includes/main/WebUI.php';

global $adb;
$nextNum = $adb->pquery('select id from 
vtiger_settings_field_seq');
$fieldId = $adb->query_result($nextNum, 0 , 'id');
$fieldId ++;

// Setting page script 
$adb->pquery("insert into vtiger_settings_field(fieldid,blockid,name,linkto)
              values ($fieldId ,4 ,'ChangeWorker','index.php?parent=Settings&module=Vtiger&view=ChangeWorker')");


              $adb->pquery("update vtiger_settings_field_seq set id=?",array($fieldId));
              echo "Done!"; die;

 -->

<?php
include_once "config.inc.php";
include_once 'include/Webservices/Relation.php';

include_once 'includes/main/WebUI.php';
include_once 'vtlib/Vtiger/Module.php';
$Vtiger_Utils_Log = true;

class customHeader{

        function __construct(){
                $this->insertHeaderLink();
        }

        function insertHeaderLink(){
                global $adb;
                $linklabel = "UpdateUser";
                $linkurl = "layouts/v7/modules/Settings/Vtiger/resources/UpdateUser.js";
                $result = $adb->pquery("SELECT * FROM vtiger_links WHERE linklabel = ? AND linkurl = ? ",array($linklabel,$linkurl));
                $num_rows = $adb->num_rows($result);
                if($num_rows == 0){
                        $moduleName='Home';
                        $moduleInstance = Vtiger_Module::getInstance($moduleName);
                        $moduleInstance->addLink('HEADERSCRIPT', $linklabel,$linkurl);
                        echo("UpdateUser Header Script Added<br/>");
                }else{
                        echo("UpdateUser Header Script Already Present<br/>");
                }
        }
}

new customHeader();
?>